//AES
package aes;
import java.util.logging.*;
import java.util.*;
import java.security.Key; 
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;

public class AES {
     private final byte[] keyValue;
    public AES(String key){
        keyValue=key.getBytes();
    }

    public static void main(String[] args) {
         try {
            Scanner sc = new Scanner(System.in);
            String line = System.getProperty("line.separator");
            sc.useDelimiter("\n");
            System.out.println("Enter String for encryption : ");
            String message = sc.next();
            System.out.println("Enter a key 128 bit [exactly 16 characters] : ");
            String key = sc.next();
            String stringKey = key;

            AES aes = new AES(stringKey);
            String encdata = aes.encrypt(message);
            System.out.println("Encrypted Data : "+encdata);
            String decdata = aes.decrypt(encdata);
            System.out.println("Decrypted Data : "+decdata);


        } catch (Exception ex) {
            Logger.getLogger(AES.class.getName()).log(Level.SEVERE,null,ex);
        }
    }

    public String encrypt(String Data) throws Exception{
        Key key = generateKey();
        Cipher c = Cipher.getInstance("AES");
        c.init(Cipher.ENCRYPT_MODE,key);
        byte[] encVal = c.doFinal(Data.getBytes());
        String encryptedValue = new sun.misc.BASE64Encoder().encode(encVal);
        return encryptedValue;
    }

    public String decrypt(String encryptedData) throws Exception{
        Key key = generateKey();
        Cipher c = Cipher.getInstance("AES");
        c.init(Cipher.DECRYPT_MODE,key);
        byte[] decordedValue = new sun.misc.BASE64Decoder().decodeBuffer(encryptedData);
        byte[] decVal = c.doFinal(decordedValue);
        String decryptedValue = new String(decVal);
        return decryptedValue;
    }

    private Key generateKey() throws Exception{
        Key key = new SecretKeySpec(keyValue, "AES");
        return key;
    }
    
    
}
