//vernamCipher
import java.lang.Math;
import java.util.*;

public class VernamCipher {

    static String generateKey(String str, String key) {
        int x = str.length();
        for (int i = 0;; i++) {
            if (x == i) {
                i = 0;
            }
            if (key.length() == str.length()) {
                break;
            }
            key += (key.charAt(i));
        }
        return key;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the String of Encryption: ");
        String text = sc.next();
        char[] arText = text.toCharArray();

        System.out.print("Enter the Key String: ");
        String keywoard = sc.next();
        String cipher = generateKey(text, keywoard);
        char[] arCipher = cipher.toCharArray();
        char[] encoded = new char[text.length()];
        System.out.println("Encoded " + text + " to be........");
        for (int i = 0; i < arText.length; i++) {
            encoded[i] = (char) (arText[i] ^ arCipher[i]);
            System.out.print(encoded[i]);
        }
        System.out.print("\n\nDecoded " + text + " to be........");
        for (int i = 0; i < encoded.length; i++) {
            char temp = (char) (encoded[i] ^ arCipher[i]);
            System.out.print(temp);
        }

    }
}
